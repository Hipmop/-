import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The lower pipe appears below the upper pipe
 * 
 * @author Sam Collins and Shane Simpkin
 * @version 0.1
 */
public class LowerPipe extends UpperPipe
{
    //All code is used from UpperPipe. Do not add and code here, edit UpperPipe. The code for adding this object is in cat
}
